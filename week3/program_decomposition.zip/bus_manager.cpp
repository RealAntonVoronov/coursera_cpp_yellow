#include "bus_manager.h"

void BusManager::AddBus(const std::string& bus, const std::vector<std::string>& stops) {
        buses_to_stops[bus] = stops;
        for (const std::string& stop : stops){
            stop_to_buses[stop].push_back(bus);
        }
    }

BusesForStopResponse BusManager::GetBusesForStop(const std::string& stop) const {
    BusesForStopResponse response;
    response.stop_exists = stop_to_buses.count(stop) != 0;
    if (response.stop_exists){
        response.buses = stop_to_buses.at(stop);
    }
    return response;
}

StopsForBusResponse BusManager::GetStopsForBus(const std::string& bus) const {
    StopsForBusResponse response;
    response.bus_exists = buses_to_stops.count(bus) != 0;
    if (response.bus_exists){
        size_t i = 0;
        response.stops_answers.resize(buses_to_stops.at(bus).size());
        for (const std::string& stop : buses_to_stops.at(bus)){
            response.stops.push_back(stop);
            for (const std::string& interchange_bus : stop_to_buses.at(stop)){
                if (interchange_bus != bus){
                    response.stops_answers[i].push_back(interchange_bus);
                }
            }
            i++;
        }
    }
    return response;
}

AllBusesResponse BusManager::GetAllBuses() const {
    return {buses_to_stops};
}