#pragma once
#include "string"
#include "vector"
#include "iostream"

enum class QueryType {
    NewBus=0,
    BusesForStop=1,
    StopsForBus=2,
    AllBuses=3
};

struct Query {
    QueryType type;
    std::string bus;
    std::string stop;
    std::vector<std::string> stops;
};

std::istream& operator >> (std::istream& is, Query& q);