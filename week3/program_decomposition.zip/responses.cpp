#include "responses.h"

std::ostream& operator << (std::ostream& os, const BusesForStopResponse& r) {
    if (r.stop_exists){
        for (const std::string& bus : r.buses){
            os << bus << " ";
        }
    }
    else os << "No stop";
    return os;
}

std::ostream& operator << (std::ostream& os, const StopsForBusResponse& r) {
    if (r.bus_exists){
        for (size_t i = 0; i < r.stops.size(); i++) {
            if (i != 0){
                os << std::endl;
            }
            os << "Stop " << r.stops[i] << ": ";
            if (r.stops_answers[i].empty()){
                os << "no interchange";
            }
            else {
                for (const std::string& bus : r.stops_answers[i]){
                    os << bus << " ";
                }
            }
        }
    }
    else os << "No bus";
    return os;
}

std::ostream& operator << (std::ostream& os, const AllBusesResponse& r) {
    if (r.all_buses.empty()){
        os << "No buses";
    }
    else{
        bool first = true;
        for (const auto& [bus, stops] : r.all_buses){
            if (!first){
                os << std::endl;
            }
            first = false;
            os << "Bus " << bus << ": ";
            for (const std::string& stop : stops){
                os << stop << " ";
            }
        }
    }
    return os;
}