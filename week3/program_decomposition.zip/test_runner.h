#ifndef COURSERA_CPP_YELLOW_TEST_RUNNER_H
#define COURSERA_CPP_YELLOW_TEST_RUNNER_H


#include "vector"
#include "sstream"
#include "iostream"
#include "set"
#include "map"
#include "string"

void Assert(bool b, const std::string& hint);

class TestRunner {
public:
    TestRunner() = default;
    template <class TestFunc>
    void RunTest(TestFunc func, const std::string& test_name) {
        try {
            func();
            std::cerr << test_name << " OK" << std::endl;
        } catch (std::exception& e) {
            ++fail_count;
            std::cerr << test_name << " fail: " << e.what() << std::endl;
        } catch (...) {
            ++fail_count;
            std::cerr << "Unknown exception caught" << std::endl;
        }
    }

    ~TestRunner();
private:
    int fail_count = 0;
};
#endif