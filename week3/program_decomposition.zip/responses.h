#pragma once
#include "vector"
#include "iostream"
#include "string"
#include "map"

struct BusesForStopResponse {
    bool stop_exists = false;
    std::vector<std::string> buses;
};

std::ostream& operator << (std::ostream& os, const BusesForStopResponse& r);

struct StopsForBusResponse {
    bool bus_exists = false;
    std::vector<std::string> stops;
    std::vector<std::vector<std::string>> stops_answers;
};

std::ostream& operator << (std::ostream& os, const StopsForBusResponse& r);

struct AllBusesResponse {
    std::map<std::string, std::vector<std::string>> all_buses;
};

std::ostream& operator << (std::ostream& os, const AllBusesResponse& r);