#include "query.h"

std::istream& operator >> (std::istream& is, Query& q) {
    std::string t, bus, stop;
    is >> t;
    if (t == "NEW_BUS"){
        q.type = QueryType::NewBus;
        int stop_count=0;
        is >> q.bus >> stop_count;
        q.stops = std::vector<std::string>(stop_count);
        for (std::string& cur_stop : q.stops){
            is >> cur_stop;
        }
    }
    else if (t == "BUSES_FOR_STOP"){
        q.type = QueryType::BusesForStop;
        is >> q.stop;
    }
    else if (t == "STOPS_FOR_BUS"){
        q.type = QueryType::StopsForBus;
        is >> q.bus;
    }
    else if (t == "ALL_BUSES"){
        q.type = QueryType::AllBuses;
    }
    return is;
}